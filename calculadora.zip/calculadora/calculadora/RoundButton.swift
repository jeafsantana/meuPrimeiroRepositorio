//
//  RoundButton.swift
//  calculadora
//
//  Created by Jessica Santana on 13/08/21.
//

import Foundation
import UIKit

@IBDesignable
class RoundButton: UIButton {

    override func layoutSubviews() {
        super.layoutSubviews()
        if isRoundButton {
            self.layer.cornerRadius = 0.5 * self.bounds.size.width
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet{
        isRoundButton = false
        self.layer.cornerRadius = cornerRadius
        }
    }
    
    @IBInspectable var isRoundButton: Bool = false {
        didSet{
            if isRoundButton {
                self.layer.cornerRadius = 0.5 * self.bounds.size.width
            }
        }
    }

    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet{
            self.layer.borderWidth = borderWidth
        }
    }

    @IBInspectable var borderColor: UIColor = UIColor.clear{
        didSet{
            self.layer.borderColor = borderColor.cgColor
        }
    }
}
