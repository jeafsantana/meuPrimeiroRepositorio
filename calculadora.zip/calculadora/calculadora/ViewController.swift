//
//  ViewController.swift
//  calculadora
//
//  Created by Jessica Santana on 13/08/21.
//

import UIKit

class ViewController: UIViewController {
    
    
    var shouldResetValue: Bool = false
    var valorA: Double = 0.0
    var valorB: Double = 0.0
    var resultado: Double? = nil
    var operacao: String = ""
    
    @IBOutlet weak var resultadoLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func realizaOperacaoCumulativaSeNecessario() {
        if valorA != 0.0 && valorB != 0.0 {
            realizaOperacao()
            exibeResultado()
        }
    }
    
    func exibeResultado() {
        if let resultado = resultado {
            
            if  resultado.truncatingRemainder(dividingBy: 1) == 0 {
                let resultadoInteger = Int(resultado)
                resultadoLabel.text = String(resultadoInteger)
            } else {
                resultadoLabel.text = String(resultado).replacingOccurrences(of: ".", with: ",")
            }
    
        } else {
            resultadoLabel.text = "0"
        }
    }
    
    func resetValues() {
        valorA = 0.0
        valorB  = 0.0
        resultado = nil
    }
    
    func realizaOperacao() {
        if valorA != 0.0 && valorB != 0.0 {
            switch operacao {
            case "divisao":
                resultado = valorA / valorB
            case "multiplicacao":
                resultado = valorA * valorB
            case "subtracao":
                resultado = valorA - valorB
            case "soma":
                resultado = valorA + valorB
            default:
                return
            }
        }
    }
    
    func atualizaValor() {
        if let resultadoString = resultadoLabel.text {
            
            if valorA != 0.0 && valorB != 0.0 {
                valorA = resultado ?? 0.0
                valorB = converteValorStringParaNumerico(valor: resultadoString)
                return
            }
            
            if valorA == 0.0 {
                valorA = converteValorStringParaNumerico(valor: resultadoString)
            } else {
                valorB = converteValorStringParaNumerico(valor: resultadoString)
            }
        }
    }
    
    
    func adicionaNoResultado(valor: String) {
        
        if let resultado = resultadoLabel.text {
            if resultado == "0" || shouldResetValue {
                resultadoLabel.text = valor
                shouldResetValue = false
                return
            }
            
            if deveAdicionarPonto(valor: resultado) {
                resultadoLabel.text = resultado + "." + valor
            } else {
                resultadoLabel.text = resultado + valor
            }
        }
    }
    
    func deveAdicionarPonto(valor: String) -> Bool {
        if quantidadeDeCaracteresSemPonto() % 3 == 0 && !valor.contains(",") {
            return true
        }
        return false
    }
    
    func quantidadeDeCaracteresSemPonto() -> Int {
        var valor = resultadoLabel.text
        
        valor?.removeAll(where: { (caractere) -> Bool in
            caractere == "."
        })
        
        return valor?.count ?? 0
    }
    
    func converteValorStringParaNumerico(valor: String) -> Double {
        if valor.contains(",") {
            let valorComPonto = valor.replacingOccurrences(of: ",", with: ".")
            return Double(valorComPonto) ?? 0
        }
        return Double(valor) ?? 0
    }
    
    
    // - MARK: Operações Matemáticas dos botões
    
    @IBAction func operacaoDivisaoButtonAction(_ sender: Any) {
        operacao = "divisao"
        shouldResetValue = true
        atualizaValor()
        realizaOperacaoCumulativaSeNecessario()
        
    }
    
    @IBAction func operacaoMultiplicacaoButtonAction(_ sender: Any) {
        operacao = "multiplicacao"
        shouldResetValue = true
        atualizaValor()
        realizaOperacaoCumulativaSeNecessario()
        
    }
    
    
    @IBAction func operacaoSubtracaoButtonAction(_ sender: Any) {
        operacao = "subtracao"
        shouldResetValue = true
        atualizaValor()
        realizaOperacaoCumulativaSeNecessario()
        
    }
    
    @IBAction func operacaoSomaButtonAction(_ sender: Any) {
        operacao = "soma"
        shouldResetValue = true
        atualizaValor()
        realizaOperacaoCumulativaSeNecessario()

    }
    
    @IBAction func resultadoButtonAction(_ sender: Any) {
        shouldResetValue = true
        atualizaValor()
        realizaOperacao()
        exibeResultado()
        
        resetValues()
    }
    
    // - MARK: Ações Lógicas dos botões
    
    @IBAction func adicionaVirgulaButtonAction(_ sender: Any) {
        if let resultado = resultadoLabel.text {
            if !resultado.contains(",") {
                resultadoLabel.text = resultado + ","
            }
        }
    }
    
    @IBAction func valorPorcentagemButtonAction(_ sender: Any) {
        
        if let resultadoString = resultadoLabel.text {
            var resultadoNumerico: Double = converteValorStringParaNumerico(valor: resultadoString)
            resultadoNumerico = resultadoNumerico / 100
            
            let resultadoString = String(resultadoNumerico)
            
            resultadoLabel.text = resultadoString.replacingOccurrences(of: ".", with: ",")
            
            shouldResetValue = true
            
        }
        
    }
    
    @IBAction func trocarSinalButtonAction(_ sender: Any) {
        
        if let resultadoString = resultadoLabel.text {
            var resultadoNumerico = converteValorStringParaNumerico(valor: resultadoString)
            resultadoNumerico = resultadoNumerico * -1
            
            resultadoLabel.text = String(resultadoNumerico)
        }
    }
    
    @IBAction func apagarCaracteresButtonAction(_ sender: Any) {
        resetValues()
        resultadoLabel.text = "0"
    }
    
    // - MARK: Ações Numéricas dos botões
    
    @IBAction func noveButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "9")
    }
    
    @IBAction func oitoButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "8")
    }
    
    @IBAction func seteButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "7")
    }
    
    @IBAction func seisButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "6")
    }
    
    @IBAction func cincoButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "5")
    }
    
    @IBAction func quatroButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "4")
    }
    
    @IBAction func tresButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "3")
    }
    
    @IBAction func doisButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "2")
    }
    
    @IBAction func umButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "1")
    }
    
    @IBAction func zeroButtonAction(_ sender: Any) {
        adicionaNoResultado(valor: "0")
    }
    
}

